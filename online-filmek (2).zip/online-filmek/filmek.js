const fs = require('fs');

const data = fs.readFileSync('data.txt', 'utf8').split('\n').map(line => {
    const [cim, mufaj, ev] = line.split('\t');
    return { cim, mufaj, ev, kep };
});

console.log(data);

