function szures(mufaj) {
    const filmek = document.querySelectorAll('.film');
    if (mufaj === 'Összes') {
      filmek.forEach(film => film.style.display = 'block');
    } else {
      filmek.forEach(film => {
        if (film.dataset.mufaj === mufaj) {
          film.style.display = 'block';
        } else {
          film.style.display = 'none';
        }
      });
    }
  }

  fetch('adatok.txt')
    .then(response => response.text())
    .then(data => {
      const filmElemek = data.split('\n').map(film => {
        const [cim, mufaj, ev, kep] = film.split('\t');
        const filmDiv = document.createElement('div');
        filmDiv.className = 'film';
        filmDiv.dataset.mufaj = mufaj;
        const filmKep = document.createElement('img');
        filmKep.src = kep;
        filmDiv.appendChild(filmKep);
        const filmCim = document.createElement('h2');
        filmCim.textContent = cim;
        filmDiv.appendChild(filmCim);
        const filmMufaj = document.createElement('p');
        filmMufaj.textContent = mufaj;
        filmDiv.appendChild(filmMufaj);
        
        return filmDiv;
      });
      const filmLista = document.getElementById('film-lista');
      filmElemek.forEach(film => filmLista.appendChild(film));
    });

  const menuElemek = document.querySelectorAll('#menu li');
  menuElemek.forEach(menuElem => {
    menuElem.addEventListener('click', () => {
      const kivalasztottMufaj = menuElem.textContent;
      szures(kivalasztottMufaj);
    });
  });

const searchInput = document.getElementById('search-input');
const searchButton = document.getElementById('search-button');

searchButton.addEventListener('click', () => {
  const searchTerm = searchInput.value.toLowerCase();
  const filmek = document.querySelectorAll('.film');

  filmek.forEach(film => {
    const filmCim = film.querySelector('h2').textContent.toLowerCase();
    if (filmCim.includes(searchTerm)) {
      film.style.display = 'block';
    } else {
      film.style.display = 'none';
    }
  });
});



const searchInput2 = document.getElementById('mufaj-search-input');
const searchButton2 = document.getElementById('mufaj-search-button');

searchButton2.addEventListener('click', (event) => {
  event.preventDefault();
  const searchTerm = searchInput2.value.toLowerCase();
  const filmek = document.querySelectorAll('.film');

  filmek.forEach(film => {
    const filmMufaj = film.querySelector('p').textContent.toLowerCase();
    if (filmMufaj.includes(searchTerm)) {
      film.style.display = 'block';
    } else {
      film.style.display = 'none';
    }
  });
});


let aktualisMufaj = 'Összes';

function szures(mufaj) {
  const filmek = document.querySelectorAll('.film');
  if (mufaj === aktualisMufaj) {
    // Ha ugyanaz a műfaj, akkor állítsa vissza az eredeti állapotot
    filmek.forEach(film => film.style.display = 'block');
    aktualisMufaj = 'Összes';
    const dropdownItems = document.querySelectorAll('.dropdown-item');
    dropdownItems.forEach(item => {
      item.classList.remove('active');
    });
  } else {
    // Különben szűrje a filmeket
    if (mufaj === 'Összes') {
      filmek.forEach(film => film.style.display = 'block');
    } else {
      filmek.forEach(film => {
        if (film.dataset.mufaj === mufaj) {
          film.style.display = 'block';
        } else {
          film.style.display = 'none';
        }
      });
    }
    aktualisMufaj = mufaj;
    const dropdownItems = document.querySelectorAll('.dropdown-item');
    dropdownItems.forEach(item => {
      if (item.textContent === aktualisMufaj) {
        item.classList.add('active');
      } else {
        item.classList.remove('active');
      }
    });
  }
}
