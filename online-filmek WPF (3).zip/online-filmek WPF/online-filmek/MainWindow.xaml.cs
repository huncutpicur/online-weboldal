﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace online_filmek
{
   
    public partial class MainWindow : Window

    {
        ObservableCollection<Film> filmek = new ObservableCollection<Film>();
        public MainWindow()
        {
            InitializeComponent();

           

            string[] sorok = File.ReadAllLines("adatok.txt");
            foreach (string sor in sorok)
            {
                string[] adatok = sor.Split('\t');
                Film film = new Film
                {
                    Cim = adatok[0],
                    Mufaj = adatok[1],
                    Ev = adatok[2],
                    Kep = adatok[3]
                };
                filmek.Add(film);
            }
            this.DataContext = filmek;
        }


        private void film1(object sender, RoutedEventArgs e)
        {
            Button gomb = sender as Button;
            Film film = gomb.DataContext as Film;
            Grid grid = (Grid)this.gridContainer;
            grid.Children.Clear();
            WrapPanel wrapPanel = new WrapPanel();
            Image image = new Image();
            image.Source = new BitmapImage(new Uri(film.Kep, UriKind.Relative));
            wrapPanel.Children.Add(image);
            StackPanel stackPanel = new StackPanel();
            stackPanel.Orientation = Orientation.Vertical;
            stackPanel.Children.Add(new Label { Content = "Cím: " + film.Cim });
            stackPanel.Children.Add(new Label { Content = "Műfaj: " + film.Mufaj });
            stackPanel.Children.Add(new Label { Content = "Megjelenési év: " + film.Ev });
            wrapPanel.Children.Add(stackPanel);
            grid.Children.Add(wrapPanel);
        }

        private void reset_Click(object sender, RoutedEventArgs e)
        {
            Grid grid = (Grid)this.gridContainer;
            grid.Children.Clear();
            if (filmTömb.Parent != null)
            {
                ((Panel)filmTömb.Parent).Children.Remove(filmTömb);
            }
            grid.Children.Add(filmTömb);
        }
        private void mufajSzures(object sender, RoutedEventArgs e)
        {
            mufajContextMenu.IsOpen = true;
        }

        private void evSzures(object sender, RoutedEventArgs e)
        {
            evContextMenu.IsOpen = true;
        }

        private void Exit(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void mufajMenuItem_Click(object sender, RoutedEventArgs e)
        {
      
            string kiválasztottMufaj = (sender as MenuItem).Header as string;

       
            if (kiválasztottMufaj == "Összes")
            {
                itemsControl.ItemsSource = filmek;
            }
            else
            {
              
                List<Film> szurtFilmek = filmek.Where(f => f.Mufaj.Contains(kiválasztottMufaj)).ToList();

             
                itemsControl.ItemsSource = szurtFilmek;
            }
        }


        private void evMenuItem_Click(object sender, RoutedEventArgs e)
        {
           
            string kiválasztottEv = (sender as MenuItem).Header as string;

       
            if (kiválasztottEv == "Összes")
            {
                itemsControl.ItemsSource = filmek;
            }
            else
            {
              
                List<Film> szurtFilmek = filmek.Where(f => f.Ev == kiválasztottEv).ToList();

                
                itemsControl.ItemsSource = szurtFilmek;
            }
        }

        private void szuroButton_Click(object sender, RoutedEventArgs e)
        {
            Button gomb = sender as Button;
            szuro(gomb.Content.ToString());
        }

        private void szuro(string mufaj)
        {
            List<Film> szurtFilmek = filmek.Where(f => f.Mufaj.Contains(mufaj)).ToList();
            itemsControl.ItemsSource = szurtFilmek;
        }


        private void evszamButton_Click(object sender, RoutedEventArgs e)
        {
            Button gomb = sender as Button;
            int evszam = int.Parse(gomb.Content.ToString());
            szuroEvszam(evszam);
        }

        private void szuroEvszam(int evszam)
        {
            List<Film> szurtFilmek = filmek.Where(f => f.Ev.Contains(Convert.ToString(evszam))).ToList();
            itemsControl.ItemsSource = szurtFilmek;
        }

    }


   
}
