﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace online_filmek
{
    public class Film
    {
        public string Cim { get; set; }
        public string Mufaj { get; set; }
        public string Ev { get; set; }
        public string Kep { get; set; }
    }
}

